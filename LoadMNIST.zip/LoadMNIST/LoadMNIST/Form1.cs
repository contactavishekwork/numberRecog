﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoadMNIST
{
    public partial class Form1 : Form
    {
        KnnClassifier knn = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void loadBtn_Click(object sender, EventArgs e)
        {
            String trainDir = "D:\\csharp2016\\DeepLearning\\MNIST\\data\\trainingAll60000\\";//"D:\\csharp2016\\DeepLearning\\MNIST\\data\\train\\";
            String testDir = "D:\\csharp2016\\DeepLearning\\MNIST\\data\\testAll10000\\";//"D:\\csharp2016\\DeepLearning\\MNIST\\data\\test\\";
            DataPoint[] trainData = ImageReader.ReadAllData(trainDir);
            DataPoint[] testData = ImageReader.ReadAllData(testDir);
           
            knn = new KnnClassifier(28 * 28, trainData);  // each image is 28x28
            double accuracy = knn.getAccuracy(testData);
            MessageBox.Show(String.Format("{0:f2} %",accuracy));
        }

        private void btnTestData_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.InitialDirectory = "D:\\csharp2016\\DeepLearning\\MNIST\\data\test";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    DataPoint dtunknown = ImageReader.ReadDataPoint(ofd.FileName);
                    picTest.Image = new Bitmap(ofd.FileName);
                    int k = 5;
                    DataPoint dtbest = knn.ClassifyOneSample(dtunknown,k);
                    if (dtbest.ClassLabel == dtunknown.ClassLabel)
                    {
                        MessageBox.Show("matched ..Label = " + dtunknown.ClassLabel.ToString());
                    }
                    else
                    {
                        MessageBox.Show("incorrect match..");
                    }
                   // picMatched.Image = dtbest.Bmp;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
