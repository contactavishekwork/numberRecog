﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadMNIST
{
    class KnnClassifier
    {
        DataPoint[] trainingData;   // entire training data
        int dimensionality;
        object olock2 = new object();

        public KnnClassifier(int dimension, DataPoint[] trainingIN)
        {
            dimensionality = dimension;
            trainingData = trainingIN;
        }

        public double getAccuracy(DataPoint[] testData)
        {
            int testSize = testData.Length;
            int correctCount = 0;
            object olock = new object();
            int count = 0;
            Parallel.For(0, testSize, (i) =>
            //for (int i = 0; i < testSize; i++)
            {
                int index = i;  // closure problem in Parallel.For if you use i diretly
                DataPoint dt = testData[index];
                int trueLabel = dt.ClassLabel;
                int k = 5;
                int estimatedLabel = ClassifySample(dt, k);
                if (estimatedLabel == trueLabel)
                {
                    lock (olock)
                    {
                        correctCount++;
                    }
                }
                //if ((i % 100) == 0)
                //    Console.WriteLine("Test loop count = " + i);
                lock (olock)
                {
                    count++;
                    if ((count % 100) == 0)
                        Console.WriteLine("Parallel loop count = " + count + " coorect count=" + correctCount);
                }
             });
            double accuracy = (correctCount / (double)testSize) * 100;
            return accuracy;
        }

        //returns the class label as an integer number 
        public int ClassifySample(DataPoint dataSample)
        {
            if (dataSample.Dimensionality != dimensionality)
            {
                throw new Exception("The input dimensionality does not match the dimensionality of the classifier.");
            }
            byte[] unknownData = dataSample.Data;
            int bestClassLabel = 0;
            double bestDistance = double.MaxValue;
            for (int i = 0; i < trainingData.Length; i++)
            {
                byte[] currentData = trainingData[i].Data;
                double currentDist = EuclidianDist(unknownData, currentData);
                int currentLabel = trainingData[i].ClassLabel;
                if (currentDist < bestDistance)
                {
                    bestDistance = currentDist;
                    bestClassLabel = currentLabel;
                }
            }
            return bestClassLabel;
        }

        public DataPoint ClassifyOneSample(DataPoint dataSample, int k)  // k nearest neighbor
        {
            if (dataSample.Dimensionality != dimensionality)
            {
                throw new Exception("The input dimensionality does not match the dimensionality of the classifier.");
            }
     
            byte[] unknownData = dataSample.Data;
            for (int i = 0; i < trainingData.Length; i++)
            {
                byte[] currentData = trainingData[i].Data;
                double currentDist = EuclidianDist(unknownData, currentData);
                trainingData[i].BestDistance = currentDist;
                int currentLabel = trainingData[i].ClassLabel;
            }
            var res  = (from d in trainingData orderby d.BestDistance select d).Take<DataPoint>(k).ToList<DataPoint>();
            // find the highest occurance between k best neighbors
            int[] occuranceCount = new int[10];  // class labels can only be between 0 to 9
            for (int i = 0; i < k; i++)
            {
                occuranceCount[res[i].ClassLabel]++;
            }
            int mostNeighborCount = (from n in occuranceCount orderby n descending select n).First<int>();
            int mostNeighborClass = Array.FindIndex(occuranceCount, n=>n==mostNeighborCount);
            var resBest = (from d in res where d.ClassLabel==mostNeighborClass orderby d.BestDistance select d).FirstOrDefault<DataPoint>();
            return resBest;
        }

        public int ClassifySample(DataPoint dataSample, int k)  // produces wrong results in paralle.for call
        {
            if (dataSample.Dimensionality != dimensionality)
            {
                throw new Exception("The input dimensionality does not match the dimensionality of the classifier.");
            }

            byte[] unknownData = dataSample.Data;
            //-----------create local storage for distance between each training point to unknown 
            //           and its label, this is to avoid data synchronization in Parallel.For
            DataPoint[] trainingDataTemp = new DataPoint[trainingData.Length];
            for (int i = 0; i < trainingDataTemp.Length; i++)
                trainingDataTemp[i] = new DataPoint(trainingData[i].ClassLabel, trainingData[i].Dimensionality, null);
            //---------------------------------------------------------------------------------

            for (int i = 0; i < trainingData.Length; i++)
            {
                byte[] currentData = trainingData[i].Data;
                double currentDist = 0;

                currentDist = EuclidianDist(unknownData, currentData);

                //trainingData[i].BestDistance = currentDist;
                //int currentLabel = trainingData[i].ClassLabel;
                trainingDataTemp[i].BestDistance = currentDist;
            }

            //var res = (from d in trainingData orderby d.BestDistance select d).Take<DataPoint>(k).ToList<DataPoint>();
            var res = (from d in trainingDataTemp orderby d.BestDistance select d).Take<DataPoint>(k).ToList<DataPoint>();

            // find the highest occurance between k best neighbors
            int[] occuranceCount = new int[10];  // class labels can only be between 0 to 9
            for (int i = 0; i < k; i++)
            {
                occuranceCount[res[i].ClassLabel]++;
            }
            int mostNeighborCount = (from n in occuranceCount orderby n descending select n).First<int>();
            int mostNeighborClass = Array.FindIndex(occuranceCount, n => n == mostNeighborCount);
            var resBest = (from d in res where d.ClassLabel == mostNeighborClass orderby d.BestDistance select d).FirstOrDefault<DataPoint>();
            return resBest.ClassLabel;
        }

        public double EuclidianDist(byte[] sample1, byte[] sample2)
        {
            double sum = 0;
            for (int i = 0; i < dimensionality; i++)
            {
                double tempSum = (sample1[i] - sample2[i]) * (sample1[i] - sample2[i]);
                sum = tempSum + sum;
            }
            sum = Math.Sqrt(sum);
            return sum;
        }
    }
}
