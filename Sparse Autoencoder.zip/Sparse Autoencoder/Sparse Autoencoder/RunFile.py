import load_MNIST
import numpy as np
import Sparse_Autoencoder
import scipy.optimize
import display_network
import softmax

# Initializing Parameters:

inputSize = 28*28
numLabels = 5
hiddenSize = 196
sparsityParam = 0.1     #Desired Activation weight of hidden units
lambdaValue = 3e-3      #Decay
beta = 3                #Weight of Sparsity Penalty

#Loading data from MNIST Dataset

images = load_MNIST.load_MNIST_images('D:\\University of Bridgeprt\\Courses\\Semester 5\\Computer Vision\\Assignment 11_AutoEncoder\\Sparse Autoencoder\\Sparse Autoencoder\\data\\mnist\\train-images.idx3-ubyte')
labels = load_MNIST.load_MNIST_labels('D:\\University of Bridgeprt\\Courses\\Semester 5\\Computer Vision\\Assignment 11_AutoEncoder\\Sparse Autoencoder\\Sparse Autoencoder\\data\mnist\\train-images.idx3-ubyte')
unlabeledIndex = np.argwhere(labels >= 5).flatten()
labeledIndex = np.argwhere(labels < 5).flatten()

numTrain = round(labeledIndex.shape[0]/2)
trainIndex = labeledIndex[0:int(numTrain)]
testIndex = labeledIndex[int(numTrain):]

unlabeledData = images[:,unlabeledIndex]

trainData = images[:, trainIndex]
trainLabels = labels[trainIndex]

testData = images[:, testIndex]
testLabels = labels[testIndex]

print '# examples in unlabeled set: {0:d}\n'.format(unlabeledData.shape[1])
print '# examples in supervised training set: {0:d}\n'.format(trainData.shape[1])
print '# examples in supervised testing set: {0:d}\n'.format(testData.shape[1])

#Training the Sparse Autoencoder

theta = Sparse_Autoencoder.initialize(hiddenSize, inputSize)

rhoValue = lambda x: Sparse_Autoencoder.sparse_autoencoder_cost(x, inputSize, hiddenSize, lambdaValue, sparsityParam, beta, unlabeledData)
executeOptions = {'maxiter': 400, 'disp': True}
executeResult = scipy.optimize.minimize(rhoValue, theta, method = 'L-BGFS-B', jac = True, options = executeOptions)
operatedTheta = executeResult.x
print executeResult

weightFactor1 = operatedTheta[0:hiddenSize*inputSize].reshape(hiddenSize, inputSize)
display_network.display_network(weightFactor1)
print 'Training Complete!!'

#Extracting the Features

trainFeatures = Sparse_Autoencoder.sparse_autoencoder(operatedTheta, hiddenSize, inputSize, trainData)
testFeatures = Sparse_Autoencoder.sparse_autoencoder(operatedTheta,hiddenSize,inputSize,testData)
print 'Feature Extraction Complete!'